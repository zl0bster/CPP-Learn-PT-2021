#pragma once
void setCursorPosition(int x, int y);
